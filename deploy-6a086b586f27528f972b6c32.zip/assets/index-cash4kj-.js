(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))s(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const o of i.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function r(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function s(n){if(n.ep)return;n.ep=!0;const i=r(n);fetch(n.href,i)}})();var $e=class extends Error{constructor(e){super(e.statusText),this.name="HTTPError",this.status=e.status}},je=class extends $e{constructor(e,t){super(e),this.name="TextHTTPError",this.data=t}},me=class extends $e{constructor(e,t){super(e),this.name="JSONHTTPError",this.json=t}},Ue=class Le{constructor(t,r){this.apiURL=t||"",this._sameOrigin=/^\/(?!\/)/.test(this.apiURL),this.defaultHeaders=(r==null?void 0:r.defaultHeaders)||{}}headers(t={}){return{...this.defaultHeaders,"Content-Type":"application/json",...t}}static async parseJsonResponse(t){const r=await t.json();if(!t.ok)throw new me(t,r);return r}async request(t,r={}){const s=this.headers(r.headers||{});r.body||delete s["Content-Type"];const n={...r,headers:s};this._sameOrigin&&(n.credentials=r.credentials||"same-origin");const i=await fetch(this.apiURL+t,n),o=i.headers.get("Content-Type");if(o!=null&&o.includes("json"))return Le.parseJsonResponse(i);const a=await i.text();if(!i.ok)throw new je(i,a);return a}},He=class{constructor(e){this.user=e}listUsers(e){return this.user._request("/admin/users",{method:"GET",audience:e})}getUser(e){return this.user._request(`/admin/users/${e.id}`)}updateUser(e,t={}){return this.user._request(`/admin/users/${e.id}`,{method:"PUT",body:JSON.stringify(t)})}createUser(e,t,r={}){return r.email=e,r.password=t,this.user._request("/admin/users",{method:"POST",body:JSON.stringify(r)})}deleteUser(e){return this.user._request(`/admin/users/${e.id}`,{method:"DELETE"})}},Ne=60*1e3,q="gotrue.user",ee={},D=null,qe={api:1,token:1,audience:1,url:1},De={api:1},J=()=>typeof window<"u",ke=!1;function Te(){!ke&&J()&&(ke=!0,window.addEventListener("storage",e=>{e.key===q&&(D=null)}))}var de=class F{constructor(t,r,s){this.token=null,this.api=t,this.url=t.apiURL,this.audience=s,this._processTokenResponse(r),D=this,Te()}static removeSavedSession(){J()&&localStorage.removeItem(q)}static recoverSession(t){if(Te(),D)return D;const r=J()&&localStorage.getItem(q);if(r)try{const s=JSON.parse(r),{url:n,token:i,audience:o}=s;if(!n||!i)return null;const a=t||new Ue(n,{});return new F(a,i,o)._saveUserData(s,!0)}catch(s){return console.error(new Error(`Gotrue-js: Error recovering session: ${s}`)),null}return null}get admin(){return new He(this)}async update(t){const r=await this._request("/user",{method:"PUT",body:JSON.stringify(t)});return this._saveUserData(r)._refreshSavedSession()}jwt(t){const r=this.tokenDetails();if(r==null)return Promise.reject(new Error("Gotrue-js: failed getting jwt access token"));const{expires_at:s,refresh_token:n,access_token:i}=r;return t||s-Ne<Date.now()?this._refreshToken(n):Promise.resolve(i)}logout(){return this._request("/logout",{method:"POST"}).then(this.clearSession.bind(this)).catch(this.clearSession.bind(this))}_refreshToken(t){const r=ee[t];if(r)return r;const s=this.api.request("/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`grant_type=refresh_token&refresh_token=${t}`}),n=new Promise((o,a)=>{setTimeout(()=>a(new Error("Token refresh timeout")),3e4)}),i=Promise.race([s,n]).then(o=>{if(delete ee[t],this._processTokenResponse(o),this._refreshSavedSession(),!this.token)throw new Error("Gotrue-js: Token not set after refresh");return this.token.access_token}).catch(o=>{throw delete ee[t],this.clearSession(),o});return ee[t]=i,i}async _request(t,r={}){r.headers=r.headers||{};const s=r.audience||this.audience;s&&(r.headers["X-JWT-AUD"]=s);try{const n=await this.jwt();return await this.api.request(t,{headers:Object.assign(r.headers,{Authorization:`Bearer ${n}`}),...r})}catch(n){throw n instanceof me&&n.json&&(n.json.msg?n.message=n.json.msg:n.json.error&&(n.message=`${n.json.error}: ${n.json.error_description}`)),n}}async getUserData(){const t=await this._request("/user");return this._saveUserData(t)._refreshSavedSession()}_saveUserData(t,r){for(const s in t)s in F.prototype||s in qe||(this[s]=t[s]);return r&&(this._fromStorage=!0),this}_processTokenResponse(t){this.token=t;try{const r=JSON.parse(Fe(t.access_token.split(".")[1]));this.token.expires_at=r.exp*1e3}catch(r){console.error(new Error(`Gotrue-js: Failed to parse tokenResponse claims: ${r}`))}}_refreshSavedSession(){return J()&&localStorage.getItem(q)&&this._saveSession(),this}get _details(){const t={};for(const r in this)r in F.prototype||r in De||(t[r]=this[r]);return t}_saveSession(){return J()&&localStorage.setItem(q,JSON.stringify(this._details)),this}tokenDetails(){return this.token}clearSession(){F.removeSavedSession(),this.token=null,D=null}};function Je(e){return typeof atob=="function"?atob(e):Buffer.from(e,"base64").toString("binary")}function Fe(e){let t=e.replace(/-/g,"+").replace(/_/g,"/");switch(t.length%4){case 0:break;case 2:t+="==";break;case 3:t+="=";break;default:throw new Error("Illegal base64url string!")}const r=Je(t);try{const s=Uint8Array.from(r,n=>n.codePointAt(0)??0);return new TextDecoder().decode(s)}catch{return r}}var Ge=/^http:\/\//,ze="/.netlify/identity",_e=class{constructor({APIUrl:e=ze,audience:t="",setCookie:r=!1,clientName:s="gotrue-js"}={}){Ge.test(e)&&console.warn(`Warning:

DO NOT USE HTTP IN PRODUCTION FOR GOTRUE EVER!
GoTrue REQUIRES HTTPS to work securely.`),t&&(this.audience=t),this.setCookie=r,this.api=new Ue(e,{defaultHeaders:{"X-Nf-Client":s}})}async _request(e,t={}){t.headers=t.headers||{};const r=t.audience||this.audience;r&&(t.headers["X-JWT-AUD"]=r);try{return await this.api.request(e,t)}catch(s){throw s instanceof me&&s.json&&(s.json.msg?s.message=s.json.msg:s.json.error&&(s.message=`${s.json.error}: ${s.json.error_description}`)),s}}settings(){return this._request("/settings")}signup(e,t,r){return this._request("/signup",{method:"POST",body:JSON.stringify({email:e,password:t,data:r})})}login(e,t,r){return this._setRememberHeaders(r),this._request("/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`grant_type=password&username=${encodeURIComponent(e)}&password=${encodeURIComponent(t)}`}).then(s=>(de.removeSavedSession(),this.createUser(s,r)))}loginExternalUrl(e){return`${this.api.apiURL}/authorize?provider=${e}`}confirm(e,t){return this._setRememberHeaders(t),this.verify("signup",e,t)}requestPasswordRecovery(e){return this._request("/recover",{method:"POST",body:JSON.stringify({email:e})})}recover(e,t){return this._setRememberHeaders(t),this.verify("recovery",e,t)}acceptInvite(e,t,r){return this._setRememberHeaders(r),this._request("/verify",{method:"POST",body:JSON.stringify({token:e,password:t,type:"signup"})}).then(s=>this.createUser(s,r))}acceptInviteExternalUrl(e,t){return`${this.api.apiURL}/authorize?provider=${e}&invite_token=${t}`}createUser(e,t=!1){return this._setRememberHeaders(t),new de(this.api,e,this.audience||"").getUserData().then(s=>(t&&s._saveSession(),s))}currentUser(){const e=de.recoverSession(this.api);return e&&this._setRememberHeaders(e._fromStorage),e}async validateCurrentSession(){const e=this.currentUser();if(!e)return null;try{return await e.getUserData()}catch{return e.clearSession(),null}}verify(e,t,r){return this._setRememberHeaders(r),this._request("/verify",{method:"POST",body:JSON.stringify({token:t,type:e})}).then(s=>this.createUser(s,r))}_setRememberHeaders(e){this.setCookie&&(this.api.defaultHeaders=this.api.defaultHeaders||{},this.api.defaultHeaders["X-Use-Cookie"]=e?"1":"session")}};typeof window<"u"&&(window.GoTrue=_e);var T={},xe=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof require<"u"?require:t)[r]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')}),Ve=["google","github","gitlab","bitbucket","facebook","email"],g=class ue extends Error{constructor(t,r,s){super(t),this.name="AuthError",this.status=r,s&&"cause"in s&&(this.cause=s.cause)}static from(t){if(t instanceof ue)return t;const r=t instanceof Error?t.message:String(t);return new ue(r,void 0,{cause:t})}},We=class extends Error{constructor(e="Netlify Identity is not available."){super(e),this.name="MissingIdentityError"}},C="/.netlify/identity",te=null,P,Ee=!1,I=()=>typeof window<"u"&&typeof window.location<"u",Ye=()=>{var e,t;if(P!==void 0)return P;if(I())P=`${window.location.origin}${C}`;else{const r=fe();r!=null&&r.url?P=r.url:(t=(e=globalThis.Netlify)==null?void 0:e.context)!=null&&t.url?P=new URL(C,globalThis.Netlify.context.url).href:typeof process<"u"&&(T!=null&&T.URL)&&(P=new URL(C,T.URL).href)}return P??null},ve=()=>{if(te)return te;const e=Ye();return e?(te=new _e({APIUrl:e,setCookie:!1}),te):(Ee||(console.warn("@netlify/identity: Could not determine the Identity endpoint URL. Make sure your site has Netlify Identity enabled, or run your app with `netlify dev`."),Ee=!0),null)},W=()=>{const e=ve();if(!e)throw new We;return e},fe=()=>{var r,s;const e=globalThis.netlifyIdentityContext;if(e!=null&&e.url)return{url:e.url,token:e.token};if((s=(r=globalThis.Netlify)==null?void 0:r.context)!=null&&s.url)return{url:new URL(C,globalThis.Netlify.context.url).href};const t=typeof process<"u"?T==null?void 0:T.URL:void 0;return t?{url:new URL(C,t).href}:null},S="nf_jwt",Y="nf_refresh",oe=e=>{if(typeof document>"u")return null;const t=document.cookie.match(new RegExp(`(?:^|; )${e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}=([^;]*)`));if(!t)return null;try{return decodeURIComponent(t[1])}catch{return t[1]}},Ce=(e,t,r)=>{e.set({name:S,value:t,httpOnly:!1,secure:!0,path:"/",sameSite:"Lax"}),r&&e.set({name:Y,value:r,httpOnly:!1,secure:!0,path:"/",sameSite:"Lax"})},Ke=e=>{e.delete(S),e.delete(Y)},H=(e,t)=>{typeof document>"u"||(document.cookie=`${S}=${encodeURIComponent(e)}; path=/; secure; samesite=lax`,t&&(document.cookie=`${Y}=${encodeURIComponent(t)}; path=/; secure; samesite=lax`))},Ie=()=>{typeof document>"u"||(document.cookie=`${S}=; path=/; secure; samesite=lax; expires=Thu, 01 Jan 1970 00:00:00 GMT`,document.cookie=`${Y}=; path=/; secure; samesite=lax; expires=Thu, 01 Jan 1970 00:00:00 GMT`)},Xe=e=>{var r,s;const t=(s=(r=globalThis.Netlify)==null?void 0:r.context)==null?void 0:s.cookies;return!t||typeof t.get!="function"?null:t.get(e)??null},O,Qe=()=>{if(O===null)return;if(O===void 0)try{if(typeof xe>"u"){O=null;return}O=xe("next/headers").headers}catch{O=null;return}const e=O;if(e)try{e()}catch(t){if(t instanceof Error&&("digest"in t||/bail\s*out.*prerende/i.test(t.message)))throw t}},Ze=5e3,z=async(e,t={},r=Ze)=>{const s=new AbortController,n=setTimeout(()=>s.abort(),r);try{return await fetch(e,{...t,signal:s.signal})}catch(i){if(i instanceof Error&&i.name==="AbortError"){const o=new URL(e).pathname;throw new g(`Identity request to ${o} timed out after ${r}ms`)}throw i}finally{clearTimeout(n)}},U={LOGIN:"login",LOGOUT:"logout",TOKEN_REFRESH:"token_refresh",USER_UPDATED:"user_updated",RECOVERY:"recovery"},et=new Set,L=(e,t)=>{for(const r of et)try{r(e,t)}catch{}},tt=60,se=null,$=()=>{if(!I())return;pe();const e=ve(),t=e==null?void 0:e.currentUser();if(!t)return;const r=t.tokenDetails();if(!(r!=null&&r.expires_at))return;const s=Math.floor(Date.now()/1e3),n=typeof r.expires_at=="number"&&r.expires_at>1e12?Math.floor(r.expires_at/1e3):r.expires_at,i=Math.max(0,n-s-tt)*1e3;se=setTimeout(async()=>{try{const o=await t.jwt(!0),a=t.tokenDetails();H(o,a==null?void 0:a.refresh_token),L(U.TOKEN_REFRESH,w(t)),$()}catch{pe()}},i)},pe=()=>{se!==null&&(clearTimeout(se),se=null)},ye=()=>{var t,r;const e=(r=(t=globalThis.Netlify)==null?void 0:t.context)==null?void 0:r.cookies;if(!e)throw new g("Server-side auth requires Netlify Functions runtime");return e},ge=()=>{const e=fe();if(!(e!=null&&e.url))throw new g("Could not determine the Identity endpoint URL on the server");return e.url},K=!0,rt=async(e,t)=>{var s;if(!I()){const n=ge(),i=ye(),o=new URLSearchParams({grant_type:"password",username:e,password:t});let a;try{a=await z(`${n}/token`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:o.toString()})}catch(d){throw g.from(d)}if(!a.ok){const d=await a.json().catch(()=>({}));throw new g(d.msg||d.error_description||`Login failed (${a.status})`,a.status)}const f=await a.json(),h=f.access_token;let u;try{u=await z(`${n}/user`,{headers:{Authorization:`Bearer ${h}`}})}catch(d){throw g.from(d)}if(!u.ok){const d=await u.json().catch(()=>({}));throw new g(d.msg||`Failed to fetch user data (${u.status})`,u.status)}const v=await u.json(),l=w(v);return Ce(i,h,f.refresh_token),l}const r=W();try{const n=await r.login(e,t,K),i=await n.jwt();H(i,(s=n.tokenDetails())==null?void 0:s.refresh_token);const o=w(n);return $(),L(U.LOGIN,o),o}catch(n){throw g.from(n)}},st=async(e,t,r)=>{var n,i,o;if(!I()){const a=ge(),f=ye();let h;try{h=await z(`${a}/signup`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:e,password:t,data:r})})}catch(l){throw g.from(l)}if(!h.ok){const l=await h.json().catch(()=>({}));throw new g(l.msg||`Signup failed (${h.status})`,h.status)}const u=await h.json(),v=w(u);if(u.confirmed_at){const l=u.access_token;l&&Ce(f,l,u.refresh_token)}return v}const s=W();try{const a=await s.signup(e,t,r),f=w(a);if(a.confirmed_at){const h=await((n=a.jwt)==null?void 0:n.call(a));if(h){const u=(o=(i=a.tokenDetails)==null?void 0:i.call(a))==null?void 0:o.refresh_token;H(h,u)}$(),L(U.LOGIN,f)}return f}catch(a){throw g.from(a)}},nt=async()=>{if(!I()){const t=ge(),r=ye(),s=r.get(S);if(s)try{await z(`${t}/logout`,{method:"POST",headers:{Authorization:`Bearer ${s}`}})}catch{}Ke(r);return}const e=W();try{const t=e.currentUser();t&&await t.logout(),Ie(),pe(),L(U.LOGOUT,null)}catch(t){throw g.from(t)}},it=async()=>{if(!I())return null;const e=window.location.hash.substring(1);if(!e)return null;const t=W(),r=new URLSearchParams(e);try{const s=r.get("access_token");if(s)return await at(t,r,s);const n=r.get("confirmation_token");if(n)return await ot(t,n);const i=r.get("recovery_token");if(i)return await lt(t,i);const o=r.get("invite_token");if(o)return ct(o);const a=r.get("email_change_token");return a?await dt(t,a):null}catch(s){throw s instanceof g?s:g.from(s)}},at=async(e,t,r)=>{const s=t.get("refresh_token")??"",n=parseInt(t.get("expires_in")??"",10),i=parseInt(t.get("expires_at")??"",10),o=await e.createUser({access_token:r,token_type:t.get("token_type")??"bearer",expires_in:isFinite(n)?n:3600,expires_at:isFinite(i)?i:Math.floor(Date.now()/1e3)+3600,refresh_token:s},K);H(r,s||void 0);const a=w(o);return $(),X(),L(U.LOGIN,a),{type:"oauth",user:a}},ot=async(e,t)=>{var i;const r=await e.confirm(t,K),s=await r.jwt();H(s,(i=r.tokenDetails())==null?void 0:i.refresh_token);const n=w(r);return $(),X(),L(U.LOGIN,n),{type:"confirmation",user:n}},lt=async(e,t)=>{var i;const r=await e.recover(t,K),s=await r.jwt();H(s,(i=r.tokenDetails())==null?void 0:i.refresh_token);const n=w(r);return $(),X(),L(U.RECOVERY,n),{type:"recovery",user:n}},ct=e=>(X(),{type:"invite",user:null,token:e}),dt=async(e,t)=>{const r=e.currentUser();if(!r)throw new g("Email change verification requires an active browser session");const s=await r.jwt(),n=`${window.location.origin}${C}`,i=await fetch(`${n}/user`,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:`Bearer ${s}`},body:JSON.stringify({email_change_token:t})});if(!i.ok){const f=await i.json().catch(()=>({}));throw new g(f.msg||`Email change verification failed (${i.status})`,i.status)}const o=await i.json(),a=w(o);return X(),L(U.USER_UPDATED,a),{type:"email_change",user:a}},X=()=>{history.replaceState(null,"",window.location.pathname+window.location.search)},ut=async()=>{if(!I())return null;const e=W(),t=e.currentUser();if(t)return $(),w(t);const r=oe(S);if(!r)return null;const s=oe(Y)??"",n=Ae(r),i=(n==null?void 0:n.exp)??Math.floor(Date.now()/1e3)+3600,o=Math.max(0,i-Math.floor(Date.now()/1e3));let a;try{a=await e.createUser({access_token:r,token_type:"bearer",expires_in:o,expires_at:i,refresh_token:s},K)}catch{return Ie(),null}const f=w(a);return $(),L(U.LOGIN,f),f},Pe=e=>typeof e=="string"&&Ve.includes(e)?e:void 0,_=e=>typeof e=="string"&&e!==""?e:void 0,Be=e=>{const t=e.roles;if(Array.isArray(t)&&t.every(r=>typeof r=="string"))return t},w=e=>{const t=e.user_metadata??{},r=e.app_metadata??{},s=t.full_name||t.name,n=t.avatar_url;return{id:e.id,email:e.email,confirmedAt:_(e.confirmed_at),createdAt:e.created_at,updatedAt:e.updated_at,role:_(e.role),provider:Pe(r.provider),name:typeof s=="string"?s:void 0,pictureUrl:typeof n=="string"?n:void 0,roles:Be(r),invitedAt:_(e.invited_at),confirmationSentAt:_(e.confirmation_sent_at),recoverySentAt:_(e.recovery_sent_at),pendingEmail:_(e.new_email),emailChangeSentAt:_(e.email_change_sent_at),lastSignInAt:_(e.last_sign_in_at),userMetadata:t,appMetadata:r}},pt=e=>{const t=e.app_metadata??{},r=e.user_metadata??{},s=r.full_name||r.name,n=r.avatar_url;return{id:e.sub??"",email:e.email,provider:Pe(t.provider),name:typeof s=="string"?s:void 0,pictureUrl:typeof n=="string"?n:void 0,roles:Be(t),userMetadata:r,appMetadata:t}},Ae=e=>{try{const t=e.split(".");if(t.length!==3)return null;const r=atob(t[1].replace(/-/g,"+").replace(/_/g,"/"));return JSON.parse(r)}catch{return null}},ht=async(e,t)=>{try{const r=await z(`${e}/user`,{headers:{Authorization:`Bearer ${t}`}});if(!r.ok)return null;const s=await r.json();return w(s)}catch{return null}},mt=()=>{var r,s;const e=fe();if(e!=null&&e.url)return e.url;if((s=(r=globalThis.Netlify)==null?void 0:r.context)!=null&&s.url)return new URL(C,globalThis.Netlify.context.url).href;const t=typeof process<"u"?T==null?void 0:T.URL:void 0;return t?new URL(C,t).href:null},vt=async()=>{if(I()){const s=ve(),n=(s==null?void 0:s.currentUser())??null;if(n){if(!oe(S)){try{n.clearSession()}catch{}return null}return $(),w(n)}const i=oe(S);return!i||!Ae(i)?null:await ut()??null}Qe();const e=globalThis.netlifyIdentityContext,t=(e==null?void 0:e.token)||Xe(S);if(t){const s=mt();if(s){const n=await ht(s,t);if(n)return n}}const r=(e==null?void 0:e.user)??null;return r?pt(r):null};const G={};let re=null;function N(e,t){G[e]=t}function x(e){if(window.location.hash==="#"+e){he(e);return}window.location.hash=e}function ft(e){const t=e.replace("#","")||"/";if(G[t])return{handler:G[t],params:{}};for(const r of Object.keys(G)){if(!r.includes(":"))continue;const s=r.split("/"),n=t.split("/");if(s.length!==n.length)continue;const i={};let o=!0;for(let a=0;a<s.length;a++)if(s[a].startsWith(":"))i[s[a].slice(1)]=n[a];else if(s[a]!==n[a]){o=!1;break}if(o)return{handler:G[r],params:i}}return null}async function he(e){re&&(re(),re=null);const t=document.getElementById("page-content");if(!t)return;const r=ft(e||window.location.hash);if(r){const s=await r.handler(t,r.params);typeof s=="function"&&(re=s)}else t.innerHTML='<div class="container" style="padding-top:4rem;text-align:center;"><h2>Page not found</h2></div>';window.scrollTo(0,0)}function yt(){window.addEventListener("hashchange",()=>he(window.location.hash)),he(window.location.hash)}const c={play:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',pause:'<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',volume:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>',volumeMute:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>',upload:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',music:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',user:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',disc:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/></svg>',dollar:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',barChart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg>',link:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>'};let A=null;const ne=[];function gt(e){return ne.push(e),()=>{const t=ne.indexOf(e);t>=0&&ne.splice(t,1)}}function V(){ne.forEach(e=>e(A))}function Q(){return A}async function bt(){try{const t=await it();if(t&&t.user)return A=t.user,V(),t}catch{}const e=await vt();return e&&(A=e,V()),null}async function wt(e,t){const r=await rt(e,t);return A=r,V(),r}async function kt(e,t,r){const s=await st(e,t,{full_name:r});return s.emailVerified&&(A=s,V()),s}async function Tt(){await nt(),A=null,V()}async function y(e,t={}){const r=await fetch(e,{headers:{"Content-Type":"application/json",...t.headers},...t});if(!r.ok){const s=await r.text();throw new Error(s||r.statusText)}return r.json()}async function xt(e,t){const r=await fetch(e,{method:"POST",body:t});if(!r.ok){const s=await r.text();throw new Error(s||r.statusText)}return r.json()}function k(e,t="info"){let r=document.querySelector(".toast-container");r||(r=document.createElement("div"),r.className="toast-container",document.body.appendChild(r));const s=document.createElement("div");s.className=`toast ${t}`,s.textContent=e,r.appendChild(s),setTimeout(()=>s.remove(),4e3)}let m=null,ie=null,E=!1,Re=.8;const ae=[];function Et(e){return ae.push(e),()=>{const t=ae.indexOf(e);t>=0&&ae.splice(t,1)}}function j(){ae.forEach(e=>e({track:ie,isPlaying:E}))}async function St(e){if(ie&&ie.id===e.id&&m){m.paused?(m.play(),E=!0):(m.pause(),E=!1),j();return}m&&(m.pause(),m.src=""),ie=e;const t=`/api/stream/${encodeURIComponent(e.blobKey)}`;m=new Audio(t),m.volume=Re,m.addEventListener("ended",()=>{E=!1,j()}),m.addEventListener("error",()=>{E=!1,j()});try{await m.play(),E=!0,j(),y("/api/streams",{method:"POST",body:JSON.stringify({trackId:e.id})}).catch(()=>{})}catch{E=!1,j()}}function $t(){m&&(m.paused?(m.play(),E=!0):(m.pause(),E=!1),j())}function Me(e){Re=e,m&&(m.volume=e)}function Ut(){return m}function Lt(e){!m||!m.duration||(m.currentTime=e*m.duration)}function Se(e){if(!e||isNaN(e))return"0:00";const t=Math.floor(e/60),r=Math.floor(e%60);return`${t}:${r.toString().padStart(2,"0")}`}async function _t(e){var r,s;const t=Q();e.innerHTML=`
    <section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1>Where <span class="gold">Bold Artists</span> Build Culture</h1>
          <p>Triumph Music Label is an independent powerhouse developing the next generation of artists. Stream exclusive music, support your favorites, and be part of something real.</p>
          <div class="hero-actions">
            <button class="btn btn-primary" id="hero-browse">Browse Music</button>
            ${t?"":'<button class="btn btn-outline" id="hero-join">Join Now</button>'}
          </div>
        </div>
      </div>
    </section>
    <section class="container" style="padding:4rem 2rem;">
      <h2 class="section-title">Featured Artists</h2>
      <p class="section-subtitle">Meet the voices shaping the sound of tomorrow</p>
      <div class="artist-grid" id="home-artists">
        <div class="skeleton" style="height:360px;border-radius:16px;"></div>
        <div class="skeleton" style="height:360px;border-radius:16px;"></div>
        <div class="skeleton" style="height:360px;border-radius:16px;"></div>
      </div>
    </section>
    <section class="container" style="padding:2rem 2rem 4rem;">
      <h2 class="section-title">Latest Tracks</h2>
      <p class="section-subtitle">Fresh releases from the label</p>
      <div class="track-grid" id="home-tracks">
        <div class="skeleton" style="height:280px;border-radius:16px;"></div>
        <div class="skeleton" style="height:280px;border-radius:16px;"></div>
        <div class="skeleton" style="height:280px;border-radius:16px;"></div>
        <div class="skeleton" style="height:280px;border-radius:16px;"></div>
      </div>
    </section>
  `,(r=document.getElementById("hero-browse"))==null||r.addEventListener("click",()=>x("/browse")),(s=document.getElementById("hero-join"))==null||s.addEventListener("click",()=>x("/login")),Ct(),It()}async function Ct(){try{const e=await y("/api/artists"),t=document.getElementById("home-artists");if(!t)return;if(e.length===0){t.innerHTML=`<div class="empty-state" style="grid-column:1/-1;">${c.user}<p>Artists coming soon</p></div>`;return}t.innerHTML=e.slice(0,6).map(r=>`
      <div class="artist-card" data-id="${r.id}">
        <div class="artist-card-img">
          ${r.imageUrl?`<img src="${r.imageUrl}" alt="${r.name}"/>`:`<div style="width:100%;height:100%;background:var(--bg-elevated);display:flex;align-items:center;justify-content:center;">${c.user}</div>`}
        </div>
        <div class="artist-card-info">
          <div class="artist-card-name">${r.name}</div>
          <div class="artist-card-genre">${r.genre||"Artist"}</div>
        </div>
      </div>
    `).join(""),t.querySelectorAll(".artist-card").forEach(r=>{r.addEventListener("click",()=>x(`/artist/${r.dataset.id}`))})}catch{const e=document.getElementById("home-artists");e&&(e.innerHTML='<div class="empty-state" style="grid-column:1/-1;"><p>Could not load artists</p></div>')}}async function It(){try{const e=await y("/api/tracks"),t=document.getElementById("home-tracks");if(!t)return;if(e.length===0){t.innerHTML=`<div class="empty-state" style="grid-column:1/-1;">${c.music}<p>No tracks yet. Be the first to upload!</p></div>`;return}be(t,e.slice(0,8))}catch{const e=document.getElementById("home-tracks");e&&(e.innerHTML='<div class="empty-state" style="grid-column:1/-1;"><p>Could not load tracks</p></div>')}}function be(e,t){e.innerHTML=t.map(r=>`
    <div class="track-card" data-track='${JSON.stringify(r).replace(/'/g,"&#39;")}'>
      <div class="track-card-cover">
        ${r.coverUrl?`<img src="${r.coverUrl}" alt="${r.title}"/>`:`<div style="width:100%;height:100%;background:var(--bg-elevated);display:flex;align-items:center;justify-content:center;">${c.disc}</div>`}
        <div class="track-card-play">${c.play}</div>
      </div>
      <div class="track-card-info">
        <div class="track-card-title">${r.title}</div>
        <div class="track-card-artist">${r.artistName||"Unknown"}</div>
      </div>
    </div>
  `).join(""),e.querySelectorAll(".track-card").forEach(r=>{r.addEventListener("click",()=>{const s=JSON.parse(r.dataset.track);St(s)})})}async function Pt(e){if(Q()){x("/dashboard");return}let t=!1;function r(){e.innerHTML=`
      <div class="auth-page">
        <div class="auth-card">
          <h2>${t?"Create Account":"Welcome Back"}</h2>
          <p class="subtitle">${t?"Join Triumph Music Label":"Sign in to your account"}</p>
          <div id="auth-message"></div>
          <form id="auth-form">
            ${t?`<div class="form-group">
              <label>Full Name</label>
              <input type="text" id="auth-name" placeholder="Your name" required />
            </div>`:""}
            <div class="form-group">
              <label>Email</label>
              <input type="email" id="auth-email" placeholder="you@example.com" required />
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" id="auth-password" placeholder="Min 8 characters" minlength="8" required />
            </div>
            <button type="submit" class="btn btn-primary" id="auth-submit">
              ${t?"Create Account":"Sign In"}
            </button>
          </form>
          <div class="auth-toggle">
            ${t?'Already have an account? <a href="#" id="toggle-auth">Sign in</a>':'Need an account? <a href="#" id="toggle-auth">Sign up</a>'}
          </div>
        </div>
      </div>
    `,document.getElementById("toggle-auth").addEventListener("click",n=>{n.preventDefault(),t=!t,r()}),document.getElementById("auth-form").addEventListener("submit",s)}async function s(n){n.preventDefault();const i=document.getElementById("auth-email").value,o=document.getElementById("auth-password").value,a=document.getElementById("auth-submit"),f=document.getElementById("auth-message");a.disabled=!0,a.textContent=t?"Creating...":"Signing in...",f.innerHTML="";try{if(t){const h=document.getElementById("auth-name").value;(await kt(i,o,h)).emailVerified?x("/dashboard"):(f.innerHTML='<div class="auth-success">Check your email to confirm your account.</div>',a.disabled=!1,a.textContent="Create Account")}else await wt(i,o),x("/dashboard")}catch(h){let u="Something went wrong. Please try again.";h instanceof g&&(h.status===401?u="Invalid email or password.":h.status===403?u="Signups are not allowed at this time.":h.status===422?u="Invalid input. Check your email and password.":u=h.message),f.innerHTML=`<div class="auth-error">${u}</div>`,a.disabled=!1,a.textContent=t?"Create Account":"Sign In"}}r()}async function Bt(e){e.innerHTML=`
    <div class="container" style="padding-top:2rem;">
      <h2 class="section-title">Browse Music</h2>
      <p class="section-subtitle">Discover tracks from Triumph artists</p>
      <div class="track-grid" id="browse-tracks">
        ${Array(8).fill('<div class="skeleton" style="height:280px;border-radius:16px;"></div>').join("")}
      </div>
      <h2 class="section-title" style="margin-top:4rem;">Artists</h2>
      <p class="section-subtitle">The roster</p>
      <div class="artist-grid" id="browse-artists">
        ${Array(4).fill('<div class="skeleton" style="height:360px;border-radius:16px;"></div>').join("")}
      </div>
    </div>
  `,At(),Rt()}async function At(){try{const e=await y("/api/tracks"),t=document.getElementById("browse-tracks");if(!t)return;if(e.length===0){t.innerHTML=`<div class="empty-state" style="grid-column:1/-1;">${c.music}<p>No tracks uploaded yet</p></div>`;return}be(t,e)}catch{const e=document.getElementById("browse-tracks");e&&(e.innerHTML='<div class="empty-state" style="grid-column:1/-1;"><p>Could not load tracks</p></div>')}}async function Rt(){try{const e=await y("/api/artists"),t=document.getElementById("browse-artists");if(!t)return;if(e.length===0){t.innerHTML=`<div class="empty-state" style="grid-column:1/-1;">${c.user}<p>No artists yet</p></div>`;return}t.innerHTML=e.map(r=>`
      <div class="artist-card" data-id="${r.id}">
        <div class="artist-card-img">
          ${r.imageUrl?`<img src="${r.imageUrl}" alt="${r.name}"/>`:`<div style="width:100%;height:100%;background:var(--bg-elevated);display:flex;align-items:center;justify-content:center;">${c.user}</div>`}
        </div>
        <div class="artist-card-info">
          <div class="artist-card-name">${r.name}</div>
          <div class="artist-card-genre">${r.genre||"Artist"}</div>
        </div>
      </div>
    `).join(""),t.querySelectorAll(".artist-card").forEach(r=>{r.addEventListener("click",()=>x(`/artist/${r.dataset.id}`))})}catch{const e=document.getElementById("browse-artists");e&&(e.innerHTML='<div class="empty-state" style="grid-column:1/-1;"><p>Could not load artists</p></div>')}}async function Mt(e){const t=Q();if(!t){x("/login");return}let r="overview",s=null,n=null,i=null;e.innerHTML='<div class="container" style="padding-top:2rem;"><div class="skeleton" style="height:400px;border-radius:16px;"></div></div>';try{s=(await y("/api/artists")).find(l=>l.identityId===t.id)}catch{}function o(){if(e.innerHTML=`
      <div class="container" style="padding-top:2rem;">
        <div class="dashboard-header">
          <div>
            <h1 style="font-family:var(--font-display);font-size:2rem;">
              ${s?`Welcome, ${s.name}`:"Artist Dashboard"}
            </h1>
            <p style="color:var(--text-secondary);font-size:0.9rem;">${t.email}</p>
          </div>
          ${s?"":'<button class="btn btn-primary" id="create-profile-btn">Create Artist Profile</button>'}
        </div>
        ${s?`
          <div class="tabs">
            <button class="tab ${r==="overview"?"active":""}" data-tab="overview">Overview</button>
            <button class="tab ${r==="upload"?"active":""}" data-tab="upload">Upload</button>
            <button class="tab ${r==="profile"?"active":""}" data-tab="profile">Profile</button>
            <button class="tab ${r==="payouts"?"active":""}" data-tab="payouts">Payouts</button>
          </div>
          <div id="tab-content"></div>
        `:'<div id="profile-setup"></div>'}
      </div>
    `,!s){const l=document.getElementById("create-profile-btn");l==null||l.addEventListener("click",()=>h(document.getElementById("profile-setup")||e,!0));return}e.querySelectorAll(".tab").forEach(l=>{l.addEventListener("click",()=>{r=l.dataset.tab,o()})});const v=document.getElementById("tab-content");r==="overview"?a(v):r==="upload"?f(v):r==="profile"?h(v,!1):r==="payouts"&&u(v)}async function a(v){v.innerHTML='<div class="skeleton" style="height:200px;border-radius:12px;margin-bottom:1rem;"></div>';try{n=await y("/api/streams")}catch{n={totalStreams:0,last30Days:0,byTrack:[]}}try{i=await y("/api/payouts")}catch{i={payouts:[],pendingEarnings:0,stripeConnected:!1}}v.innerHTML=`
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-label">Total Streams</div>
          <div class="stat-value">${n.totalStreams.toLocaleString()}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Last 30 Days</div>
          <div class="stat-value">${n.last30Days.toLocaleString()}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Pending Earnings</div>
          <div class="stat-value gold">$${(i.pendingEarnings/100).toFixed(2)}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Stripe Connect</div>
          <div class="stat-value" style="font-size:1rem;">
            ${i.stripeConnected?'<span class="badge badge-active">Connected</span>':'<span class="badge badge-pending">Not Set Up</span>'}
          </div>
        </div>
      </div>
      <div class="dashboard-section">
        <h3>Streams by Track</h3>
        ${n.byTrack.length===0?'<div class="empty-state"><p>No stream data yet. Upload tracks and share them!</p></div>':`<div class="table-wrap"><table>
              <thead><tr><th>Track</th><th>Streams</th></tr></thead>
              <tbody>${n.byTrack.map(l=>`<tr><td>${l.title}</td><td>${l.count.toLocaleString()}</td></tr>`).join("")}</tbody>
            </table></div>`}
      </div>
    `}function f(v){v.innerHTML=`
      <div class="dashboard-section">
        <h3>Upload New Track</h3>
        <form id="upload-form" style="max-width:560px;">
          <div class="upload-zone" id="drop-zone">
            ${c.upload}
            <p>Drop an audio file here or click to browse</p>
            <div class="hint">MP3, WAV, FLAC — up to 50 MB</div>
            <input type="file" id="audio-file" accept="audio/*" style="display:none;" />
          </div>
          <div id="file-name" style="margin:1rem 0;color:var(--text-secondary);font-size:0.88rem;"></div>
          <div class="form-group">
            <label>Track Title</label>
            <input type="text" id="track-title" placeholder="Name your track" required />
          </div>
          <div class="form-group">
            <label>Genre</label>
            <input type="text" id="track-genre" placeholder="e.g. Gospel, Afrobeat, R&B" />
          </div>
          <div class="form-group">
            <label>Cover Image URL (optional)</label>
            <input type="text" id="track-cover" placeholder="https://..." />
          </div>
          <button type="submit" class="btn btn-primary" id="upload-btn">Upload Track</button>
        </form>
      </div>
    `;const l=document.getElementById("drop-zone"),d=document.getElementById("audio-file"),b=document.getElementById("file-name");l.addEventListener("click",()=>d.click()),l.addEventListener("dragover",p=>{p.preventDefault(),l.classList.add("dragover")}),l.addEventListener("dragleave",()=>l.classList.remove("dragover")),l.addEventListener("drop",p=>{p.preventDefault(),l.classList.remove("dragover"),p.dataTransfer.files.length&&(d.files=p.dataTransfer.files,b.textContent=p.dataTransfer.files[0].name)}),d.addEventListener("change",()=>{d.files.length&&(b.textContent=d.files[0].name)}),document.getElementById("upload-form").addEventListener("submit",async p=>{p.preventDefault();const le=d.files[0];if(!le){k("Please select an audio file","error");return}const Z=document.getElementById("upload-btn");Z.disabled=!0,Z.textContent="Uploading...";const R=new FormData;R.append("audio",le),R.append("title",document.getElementById("track-title").value),R.append("genre",document.getElementById("track-genre").value),R.append("coverUrl",document.getElementById("track-cover").value);try{const M=new Audio;M.src=URL.createObjectURL(le),await new Promise(ce=>{M.addEventListener("loadedmetadata",()=>{R.append("duration",String(Math.round(M.duration))),ce()}),M.addEventListener("error",ce),setTimeout(ce,3e3)}),await xt("/api/tracks",R),k("Track uploaded!","success"),r="overview",o()}catch(M){k(M.message||"Upload failed","error"),Z.disabled=!1,Z.textContent="Upload Track"}})}function h(v,l){v.innerHTML=`
      <div class="dashboard-section">
        <h3>${l?"Create Your Artist Profile":"Edit Profile"}</h3>
        <form id="profile-form" class="profile-form">
          <div class="form-group">
            <label>Artist Name</label>
            <input type="text" id="profile-name" value="${(s==null?void 0:s.name)||""}" placeholder="Your artist name" required />
          </div>
          <div class="form-group">
            <label>Genre</label>
            <input type="text" id="profile-genre" value="${(s==null?void 0:s.genre)||""}" placeholder="e.g. Gospel, Afrobeat" />
          </div>
          <div class="form-group">
            <label>Bio</label>
            <textarea id="profile-bio" rows="4" placeholder="Tell your story...">${(s==null?void 0:s.bio)||""}</textarea>
          </div>
          <div class="form-group">
            <label>Profile Image URL</label>
            <input type="text" id="profile-image" value="${(s==null?void 0:s.imageUrl)||""}" placeholder="https://..." />
          </div>
          <button type="submit" class="btn btn-primary" id="profile-btn">
            ${l?"Create Profile":"Save Changes"}
          </button>
        </form>
      </div>
    `,document.getElementById("profile-form").addEventListener("submit",async d=>{d.preventDefault();const b=document.getElementById("profile-btn");b.disabled=!0,b.textContent="Saving...";try{s=await y("/api/artists",{method:"POST",body:JSON.stringify({name:document.getElementById("profile-name").value,genre:document.getElementById("profile-genre").value,bio:document.getElementById("profile-bio").value,imageUrl:document.getElementById("profile-image").value})}),k("Profile saved!","success"),r="overview",o()}catch(p){k(p.message||"Could not save profile","error"),b.disabled=!1,b.textContent=l?"Create Profile":"Save Changes"}})}async function u(v){v.innerHTML='<div class="skeleton" style="height:200px;border-radius:12px;"></div>';let l;try{i=await y("/api/payouts")}catch{i=i||{payouts:[],pendingEarnings:0,stripeConnected:!1}}try{l=await y("/api/stripe-connect")}catch{l={connected:!1,onboarded:!1}}v.innerHTML=`
      <div class="dashboard-section">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem;">
          <h3 style="margin:0;">Payouts</h3>
          <div style="display:flex;gap:0.75rem;flex-wrap:wrap;">
            ${l.onboarded?`<button class="btn btn-primary btn-sm" id="request-payout-btn">${c.dollar} Request Payout</button>`:`<button class="btn btn-outline btn-sm" id="connect-stripe-btn">${c.link} Set Up Stripe Connect</button>`}
          </div>
        </div>
        <div class="stats-grid" style="margin-bottom:2rem;">
          <div class="stat-card">
            <div class="stat-label">Pending Earnings</div>
            <div class="stat-value gold">$${(i.pendingEarnings/100).toFixed(2)}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Rate Per Stream</div>
            <div class="stat-value" style="font-size:1.2rem;">$0.004</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Stripe Status</div>
            <div class="stat-value" style="font-size:1rem;">
              ${l.onboarded?'<span class="badge badge-active">Active</span>':l.connected?'<span class="badge badge-pending">Pending</span>':'<span class="badge badge-failed">Not Connected</span>'}
            </div>
          </div>
        </div>
        <h3>Payout History</h3>
        ${i.payouts.length===0?'<div class="empty-state"><p>No payouts yet</p></div>':`<div class="table-wrap"><table>
              <thead><tr><th>Date</th><th>Amount</th><th>Status</th></tr></thead>
              <tbody>${i.payouts.map(p=>`
                <tr>
                  <td>${new Date(p.createdAt).toLocaleDateString()}</td>
                  <td>$${(p.amount/100).toFixed(2)}</td>
                  <td><span class="badge badge-${p.status==="completed"?"active":p.status==="pending"?"pending":"failed"}">${p.status}</span></td>
                </tr>
              `).join("")}</tbody>
            </table></div>`}
      </div>
    `;const d=document.getElementById("connect-stripe-btn");d==null||d.addEventListener("click",async()=>{d.disabled=!0,d.textContent="Redirecting...";try{const p=await y("/api/stripe-connect",{method:"POST"});p.url?window.location.href=p.url:p.alreadyOnboarded&&(k("Already connected to Stripe","success"),u(v))}catch(p){k(p.message||"Could not connect Stripe","error"),d.disabled=!1,d.textContent="Set Up Stripe Connect"}});const b=document.getElementById("request-payout-btn");b==null||b.addEventListener("click",async()=>{if(i.pendingEarnings<100){k("Minimum payout is $1.00","error");return}b.disabled=!0,b.textContent="Processing...";try{await y("/api/payouts",{method:"POST"}),k("Payout requested!","success"),u(v)}catch(p){k(p.message||"Payout failed","error"),b.disabled=!1,b.textContent="Request Payout"}})}o()}async function Ot(e){const t=Q(),r=window.location.hash.includes("?")?new URLSearchParams(window.location.hash.split("?")[1]):new URLSearchParams,s=r.get("success"),n=r.get("canceled");let i=null;if(t)try{i=await y("/api/subscribe")}catch{}e.innerHTML=`
    <div class="container" style="padding-top:2rem;">
      ${s?'<div class="auth-success" style="max-width:480px;margin:0 auto 1.5rem;text-align:center;">Welcome to Triumph Premium! Your subscription is active.</div>':""}
      ${n?'<div class="auth-error" style="max-width:480px;margin:0 auto 1.5rem;text-align:center;">Subscription was canceled. You can try again anytime.</div>':""}
      <div class="subscribe-card">
        <h2 class="section-title">Triumph Premium</h2>
        <div class="subscribe-price">$4.99<span> /month</span></div>
        <p style="color:var(--text-secondary);margin-bottom:1.5rem;">Unlimited streaming. Support the artists you love.</p>
        <ul class="subscribe-features">
          <li>${c.check} Unlimited high-quality streaming</li>
          <li>${c.check} Ad-free listening experience</li>
          <li>${c.check} Early access to new releases</li>
          <li>${c.check} Direct artist support through stream revenue</li>
          <li>${c.check} Exclusive content and behind-the-scenes</li>
        </ul>
        ${i&&i.subscribed?`<div class="auth-success" style="margin-bottom:1rem;">You're subscribed! Premium is active.</div>
             <button class="btn btn-outline" disabled>Active Subscription</button>`:`<button class="btn btn-primary" id="subscribe-btn" style="width:100%;">
              ${t?"Subscribe Now":"Sign In to Subscribe"}
            </button>`}
      </div>
    </div>
  `;const o=document.getElementById("subscribe-btn");o==null||o.addEventListener("click",async()=>{if(!t){x("/login");return}o.disabled=!0,o.textContent="Redirecting to checkout...";try{const a=await y("/api/subscribe",{method:"POST"});if(a.alreadySubscribed){o.textContent="Already Subscribed";return}a.url&&(window.location.href=a.url)}catch{o.disabled=!1,o.textContent="Subscribe Now"}})}async function jt(e,t){const r=t.id;e.innerHTML='<div class="container" style="padding-top:2rem;"><div class="skeleton" style="height:300px;border-radius:16px;margin-bottom:2rem;"></div></div>';try{const s=await y(`/api/artists/${r}`),i=(await y("/api/tracks")).filter(o=>o.artistId===s.id);if(e.innerHTML=`
      <div class="container" style="padding-top:2rem;">
        <div style="display:flex;gap:2rem;align-items:flex-start;margin-bottom:3rem;flex-wrap:wrap;">
          <div style="width:200px;height:200px;border-radius:var(--radius-lg);overflow:hidden;background:var(--bg-surface);flex-shrink:0;">
            ${s.imageUrl?`<img src="${s.imageUrl}" alt="${s.name}" style="width:100%;height:100%;object-fit:cover;"/>`:`<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--text-muted);">${c.user}</div>`}
          </div>
          <div style="flex:1;min-width:240px;">
            <div style="font-size:0.82rem;text-transform:uppercase;letter-spacing:0.08em;color:var(--gold);margin-bottom:0.5rem;">Artist</div>
            <h1 style="font-family:var(--font-display);font-size:2.5rem;margin-bottom:0.5rem;">${s.name}</h1>
            ${s.genre?`<div style="color:var(--text-secondary);margin-bottom:1rem;">${s.genre}</div>`:""}
            ${s.bio?`<p style="color:var(--text-secondary);line-height:1.7;max-width:500px;">${s.bio}</p>`:""}
          </div>
        </div>
        <h2 class="section-title">Tracks</h2>
        <p class="section-subtitle">${i.length} track${i.length!==1?"s":""}</p>
        <div class="track-grid" id="artist-tracks">
          ${i.length===0?`<div class="empty-state" style="grid-column:1/-1;">${c.music}<p>No tracks yet</p></div>`:""}
        </div>
      </div>
    `,i.length>0){const o=document.getElementById("artist-tracks");be(o,i.map(a=>({...a,artistName:a.artistName||s.name})))}}catch{e.innerHTML='<div class="container" style="padding-top:2rem;"><div class="empty-state"><p>Artist not found</p></div></div>'}}N("/",_t);N("/login",Pt);N("/browse",Bt);N("/dashboard",Mt);N("/subscribe",Ot);N("/artist/:id",jt);const Ht=document.getElementById("app");Ht.innerHTML=`
  <nav class="nav">
    <a href="#/" class="nav-logo">Triumph</a>
    <div class="nav-links" id="nav-links"></div>
  </nav>
  <main class="page" id="page-content"></main>
  <div class="player-bar" id="player-bar">
    <div class="player-cover" id="player-cover"></div>
    <div class="player-info">
      <div class="player-title" id="player-title"></div>
      <div class="player-artist" id="player-artist"></div>
    </div>
    <div class="player-controls">
      <button class="play-btn" id="player-play-btn">${c.play}</button>
    </div>
    <div class="player-progress">
      <span class="player-time" id="player-current">0:00</span>
      <div class="progress-bar" id="progress-bar">
        <div class="progress-fill" id="progress-fill"></div>
      </div>
      <span class="player-time" id="player-duration">0:00</span>
    </div>
    <div class="player-volume">
      <button id="volume-btn">${c.volume}</button>
      <div class="volume-slider" id="volume-slider">
        <div class="volume-fill" id="volume-fill" style="width:80%;"></div>
      </div>
    </div>
  </div>
`;function we(){const e=Q(),t=document.getElementById("nav-links"),r=window.location.hash.replace("#","")||"/";t.innerHTML=`
    <a href="#/browse" class="${r==="/browse"?"active":""}">Browse</a>
    <a href="#/subscribe" class="${r==="/subscribe"?"active":""}">Premium</a>
    ${e?`<a href="#/dashboard" class="${r==="/dashboard"?"active":""}">Dashboard</a>
         <button class="btn btn-ghost btn-sm" id="logout-btn">Sign Out</button>`:'<a href="#/login" class="btn btn-primary btn-sm">Sign In</a>'}
  `;const s=document.getElementById("logout-btn");s==null||s.addEventListener("click",async()=>{await Tt(),x("/")})}gt(we);window.addEventListener("hashchange",we);Et(({track:e,isPlaying:t})=>{const r=document.getElementById("player-bar");if(!e){r.classList.remove("active");return}r.classList.add("active"),document.getElementById("player-title").textContent=e.title,document.getElementById("player-artist").textContent=e.artistName||"";const s=document.getElementById("player-cover");s.innerHTML=e.coverUrl?`<img src="${e.coverUrl}" alt="${e.title}"/>`:c.disc,document.getElementById("player-play-btn").innerHTML=t?c.pause:c.play});document.getElementById("player-play-btn").addEventListener("click",$t);document.getElementById("progress-bar").addEventListener("click",e=>{const t=e.currentTarget.getBoundingClientRect();Lt((e.clientX-t.left)/t.width)});let B=!1;document.getElementById("volume-btn").addEventListener("click",()=>{B=!B,Me(B?0:.8),document.getElementById("volume-btn").innerHTML=B?c.volumeMute:c.volume,document.getElementById("volume-fill").style.width=B?"0%":"80%"});document.getElementById("volume-slider").addEventListener("click",e=>{const t=e.currentTarget.getBoundingClientRect(),r=Math.max(0,Math.min(1,(e.clientX-t.left)/t.width));Me(r),document.getElementById("volume-fill").style.width=r*100+"%",B=r===0,document.getElementById("volume-btn").innerHTML=B?c.volumeMute:c.volume});function Oe(){const e=Ut();if(e&&e.duration){const t=e.currentTime/e.duration*100;document.getElementById("progress-fill").style.width=t+"%",document.getElementById("player-current").textContent=Se(e.currentTime),document.getElementById("player-duration").textContent=Se(e.duration)}requestAnimationFrame(Oe)}requestAnimationFrame(Oe);async function Nt(){await bt(),we(),yt()}Nt();
